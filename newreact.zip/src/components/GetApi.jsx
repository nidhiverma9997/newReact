import React, { useState, useEffect } from 'react';
import { Table, Button, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Pagination from '@material-ui/lab/Pagination';
// import { } from "react-icons/fa";
import { TailSpin  } from 'react-loader-spinner'

const GetApiUrl = `https://jsonplaceholder.typicode.com/albums`;
const GetApi = () => {

    const [data, setData] = useState([])

    useEffect(() => {
        setTimeout(() => {
            fetchData();
        }, 2000);
        // fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const { data: response } = await axios.get(`${GetApiUrl}`);
            console.log('response>>', response)
            setData(response);
        } catch (error) {
            console.error(error.message);
        }
    }
    const deleteData = (id) => {
        // alert(id);
        const newData = data.filter((item) => {
            return item.id !== id;
        })
        setData(newData);
    }

    const addData = () => {
        alert();
    }

    return (
        <div className="card mt-5 container" style={{ width: '80%' }} >
            <div className="card-body">
                <Row>
                    <Col sm={8}><h2 className="card-title">Table Structure Get Data</h2></Col>
                    <Col sm={4}>
                        <Link to={`/ragistrationPage`}>
                            <Button variant="primary">Add User</Button>
                        </Link>
                    </Col>
                </Row>

                <div>

                    <Table className="table">
                        <thead className="thead-light">
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">UserId</th>
                                <th scope="col">Title</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                data.length > 0 ? data.map((item) => (
                                    <tr>
                                        <td>{item.id}</td>
                                        <td>{item.userId}</td>
                                        <td>{item.title}</td>
                                        <td>
                                            <Link to={`/edit`}>
                                                <Button variant="info"
                                                    onClick={() => addData(item.id)}>Edit</Button>
                                            </Link>
                                        </td>
                                        <td>
                                            <Button variant="danger"
                                                onClick={() => deleteData(item.id)}>
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                                    : <TailSpin  ariaLabel="loading-indicator" height={80} width={100} />
                            }
                        </tbody>
                    </Table>
                </div>

                <div style={{ display: 'block', padding: 30 }}>
                    <Pagination count={10} />
                </div>
            </div>
        </div>
    )
}
export default GetApi;