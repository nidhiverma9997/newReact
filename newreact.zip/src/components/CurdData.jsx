import React from 'react';
import { useState } from 'react';
import { Table, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const CurdData = () => {

    const ObjectData = [
        {
            id: 1,
            name: 'Gagan',
            address: 'alg',
            email: 'gagan@gmail.com'
        },
        {
            id: 2,
            name: 'Gagan sharma',
            address: 'agr',
            email: 'gagansharma@gmail.com'
        },
        {
            id: 3,
            name: ' Umesh',
            address: 'mathura',
            email: 'umesh@gmail.com'
        },
        {
            id: 4,
            name: 'Deepak',
            address: 'hariyana',
            email: 'deepak@gmail.com'
        },
        {
            id: 5,
            name: 'Sunil',
            address: 'alg',
            email: 'sunil@gmail.com'
        },
        {
            id: 6,
            name: 'Pramod',
            address: 'agr',
            email: 'pramod@gmail.com'
        },
        {
            id: 7,
            name: 'Rahul',
            address: 'alg',
            email: 'rahul@gmail.com'
        },
        {
            id: 8,
            name: 'Deepak',
            address: 'alg',
            email: 'deepak@gmail.com'
        },
    ]
    console.log('ObjectData>>', ObjectData)
    const [getData, setGetData] = useState(ObjectData);

    const addData = (id) => {
        alert(id)
        const newUpdateData = getData.filter((item) => {
            return item.id == id;
        })
        setGetData(newUpdateData);
    }

    const deleteData = (id) => {
        alert(id);
        const newData = getData.filter((item) => {
            return item.id !== id;
        })
        setGetData(newData);
    }
    return (
        <>
            <div>
                <Table className="table mt-5">
                    <thead className="thead-light">
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Address</th>
                            <th scope="col">Email</th>
                            <th scope='col'>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            getData.map((item) => (
                                <tr>
                                    <td>{item.id}</td>
                                    <td>{item.name}</td>
                                    <td>{item.address}</td>
                                    <td>{item.email}</td>
                                    <td>
                                        <Link to={'/editCourdData'}>
                                            <Button variant="info"
                                                onClick={() => addData(item.id)}>Edit</Button>
                                        </Link>
                                    </td> 
                                    <td>
                                        <Button variant="danger"
                                            onClick={() => deleteData(item.id)}>
                                            Delete
                                        </Button>
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </Table>
            </div>
        </>
    )
}
export default CurdData;