import React from 'react'
import { Button, Table } from 'react-bootstrap';
// import 'bootstrap/dist/css/bootstrap.min.css';
import Array from './Array';
import { Link, useNavigate } from 'react-router-dom';

function Main() {
    let history = useNavigate()
    function setID(id, name, age) {
        localStorage.setItem('id', id);
        localStorage.setItem('Name', name);
        localStorage.setItem('Age', age);
    }

    function deleted(id) {
        var index = Array.map(function (e) { return e.id; }).indexOf(id);
        Array.splice(index, 1)
        history('/')
    }

    return (
        <div style={{ margin: '10rem' }}>
            <Table striped bordered hover size="sm">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {Array.map((item) => {
                        return (
                            <tr>
                                <td>{item.Name}</td>
                                <td>{item.Age}</td>

                                <td><Link to={`/edit`}><Button onClick={(e) =>
                                    setID(item.id, item.Name, item.Age)} variant="info">
                                    Edit</Button></Link></td>

                                <td><Button onClick={e => deleted(item.id)}
                                    variant="danger">Delete</Button></td>
                            </tr>
                        )
                    })}
                </tbody>
            </Table>

            <Link className="d-grid gap-2" to='/create'>
                <Button variant="warning" size="lg">Add User</Button>
            </Link>

            <h4>
                New directary Open
            </h4>
            <div>
                <Link className="d-grid gap-2" to='/GetApi'>
                    <Button variant="info" size="lg">
                        Get data
                    </Button>
                </Link>
            </div>
        </div>
    )
}

export default Main;