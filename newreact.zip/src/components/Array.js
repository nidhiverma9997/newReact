const array = [
    {
        id:'1', 
        Name:'Shivansh',
        Age:'23'
    },
    {
        id:'2', 
        Name:'Simran',
        Age:'22'
    },
    {
        id:'3',
        Name:'Aakash',
        Age:'23'
    }
]
  
export default array;