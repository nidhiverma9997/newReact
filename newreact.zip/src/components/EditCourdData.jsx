import React from 'react';
import { Card } from 'react-bootstrap';
import { Formik, Form, Field, ErrorMessage, } from "formik";

const EditCourdData = () => {

    return (
        <>
            <div className='container'>
                <Card className='mt-5 mb-5 w-50 row '>
                    <div className='mt-5 col-lg-12'>

                        <Formik
                            initialValues={{ name: '', email: "", password: "" }}
                            // validationSchema={LoginSchema}
                            onSubmit={(values) => {
                                console.log(values);

                            }}
                        >
                            {({ touched, errors, isSubmitting, values }) =>
                            (
                                <div className="row mb-3">
                                    <h3>Edit Data</h3>
                                    <Form>
                                        <div className="form-group">
                                            <label htmlFor="name" className="mt-3">Id</label>
                                            <Field
                                                type="text"
                                                name="id"
                                                placeholder="Enter Id"
                                                autocomplete="off"
                                                className={`mt-2 form-control
                                            ${touched.id && errors.id ? "is-invalid" : ""}`}
                                            />
                                            <ErrorMessage
                                                component="div"
                                                name="id"
                                                className="invalid-feedback"
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="name" className="mt-3">Name</label>
                                            <Field
                                                type="text"
                                                name="name"
                                                placeholder="Enter Name"
                                                autocomplete="off"
                                                className={`mt-2 form-control
                                                ${touched.name && errors.name ? "is-invalid" : ""}`}
                                            />
                                            <ErrorMessage
                                                component="div"
                                                name="name"
                                                className="invalid-feedback"
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="address" className="mt-3">
                                                Address
                                            </label>
                                            <Field
                                                type="text"
                                                name="address"
                                                placeholder="Enter Address"
                                                className={`mt-2 form-control
                                                ${touched.address && errors.address
                                                        ? "is-invalid"
                                                        : ""
                                                    }`}
                                            />
                                            <ErrorMessage
                                                component="div"
                                                name="address"
                                                className="invalid-feedback"
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="email" className="mt-3">
                                                Email
                                            </label>
                                            <Field
                                                type="email"
                                                name="email"
                                                placeholder="Enter Email"
                                                className={`mt-2 form-control
                                                ${touched.email && errors.email
                                                        ? "is-invalid"
                                                        : ""
                                                    }`}
                                            />
                                            <ErrorMessage
                                                component="div"
                                                name="email"
                                                className="invalid-feedback"
                                            />
                                        </div>
                                        <button
                                            type="submit"
                                            className="btn btn-primary btn-block mt-4"
                                        >
                                            Submit
                                        </button>
                                    </Form>
                                </div>
                            )
                            }
                        </Formik>
                    </div>
                </Card>
            </div>
        </>
    )
}
export default EditCourdData;