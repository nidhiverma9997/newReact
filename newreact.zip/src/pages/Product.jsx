import React from 'react';
import Header from './Header';
const Product = () => {
    return (
        <>
            <div className='container card mt-5'>
                <Header />
            </div>
        </>
    )
}
export default Product;