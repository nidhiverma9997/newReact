import React from 'react';

const Product = () => {
    return(
        <>
           <h1>this is a Product Page</h1> 
        </>
    )
}
export default Product;