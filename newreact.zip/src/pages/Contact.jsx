import React from 'react';

const Contact = () => {
    const obj = {
        a: {
          // To safely update obj.a.c, we have to copy each piece
          c: 3
        },
        b: 2
      }
      
      const obj2 = {
        // copy obj
        ...obj,
        // overwrite a
        a: {
          // copy obj.a
          ...obj.a,
          // overwrite c
          c: 42
        }
      }
      console.log('obj2>>',obj2);

      const arr = ['a', 'b']
      // Create a new copy of arr, with "c" appended to the end
      const arr2 = arr.concat('c')
      console.log('arr2>>',arr2)
      // or, we can make a copy of the original array:
      const arr3 = arr.slice()
      // and mutate the copy:
     const arr4= arr3.push('c')
console.log('arr4>>',arr4)



    return(
        <>
            <h1>this is a Contact page</h1>
        </>
    )
}
export default Contact;