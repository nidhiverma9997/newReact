import React, { useState } from 'react';

const Home = () => {
  var a;
  function demo() {
    a = 10;
    console.log('a>>', a)
    var b = 3;
    console.log('b>>', b)
    var c;
  }
  // c = 8;
  // console.log('c>>', c);
  demo();
  console.log('outeraa>>', a)
  // console.log('outerb>>', b)
  // console.log('outerc>>', c);
  let value = true;
  value = String(value);
console.log('stringType>>>',typeof value);

// console.log('num','1'+3 +(3+5+4))

var a, b, c;

a = b = c = 2 + 2;

console.log(a)
console.log(b)
console.log(c)


  return (
    <div className='container-fluid'>
      <h1> this is Home page </h1>
    </div>
  )




























}
export default Home;
