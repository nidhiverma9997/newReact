import React, { useState } from 'react';
import careerBanner from '../veiws/images/careerBanner.png';
const Home = () => {

  return (
    <div className='container-fluid'>
      {/* <div className=''>
        <img className='w-100' src={careerBanner} />
      </div>
      <div className='row'>
        <div className='col-sm-3'>
          <h4>col 1st</h4>
        </div>
        <div className='col-sm-3'>
          <h4>col 2nd</h4>
        </div>
        <div className='col-sm-3'>
          <h4>col 3rd</h4>
        </div>
        <div className='col-sm-3'>
          <h4>col 4th</h4>
        </div>
      </div> */}
    </div>
  )
}
export default Home;
