import React, {useState} from 'react';
import {Alert} from 'react-bootstrap'
const Card = () => {

    const [show, setShow] = useState(true);

  if (show) {
    return (
        
        <Alert variant="danger" style={{width: 500}} className='m-5' onClose={() => setShow(false)} dismissible>
        <Alert.Heading>Oh snap! You got an error!</Alert.Heading>
        <div >
        <p>
          Change this and that and try again. Duis mollis, est non commodo
          luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
          Cras mattis consectetur purus sit amet fermentum.
        </p>
        </div>
      </Alert>
    )
}
}
export default Card;