import React from 'react';
import { Formik, Form, Field, ErrorMessage, } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from "react-router-dom";
// import RagistrationPage from './RagistrationPage';


const LoginSchema = Yup.object().shape({
    email: Yup.string()
        .email("Invalid email address format")
        .required("Email is required"),
    password: Yup.string()
        .min(3, "Password must be 3 characters at minimum")
        .required("Password is required"),
});

const Login = () => {
    
    let navigate = useNavigate();

    return (
        <div className="card container mt-5" style={{ width: "35%" }}>
            <div className="">
                <Formik
                    initialValues={{ email: "", password: "" }}
                    validationSchema={LoginSchema}
                    onSubmit={(values) => {
                        console.log(values);
                        toast.success("Login successfully!");
                        navigate("/getApi");
                    }}
                >
                    {({ touched, errors, isSubmitting, values }) =>
                    (
                        <div className='p-3'>
                            <div className="row mb-3">
                                <div className="col-lg-12 text-center">
                                    <h3 className="">Login Form</h3>
                                </div>
                            </div>
                            <Form>
                                <div className="form-group">
                                    <label htmlFor="email">Email</label>
                                    <Field
                                        type="email"
                                        name="email"
                                        placeholder="Enter email"
                                        autocomplete="off"
                                        className={`mt-2 form-control
                                  ${touched.email && errors.email ? "is-invalid" : ""}`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="email"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="password" className="mt-3">
                                        Password
                                    </label>
                                    <Field
                                        type="password"
                                        name="password"
                                        placeholder="Enter password"
                                        className={`mt-2 form-control
                                           ${touched.password && errors.password
                                                ? "is-invalid"
                                                : ""
                                            }`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="password"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <button
                                    type="submit"
                                    className="btn btn-primary btn-block mt-4"
                                >
                                    Submit
                                </button>
                            </Form>
                        </div>
                    )
                    }
                </Formik>
            </div>

            <ToastContainer />
        </div>
    )
}
export default Login;