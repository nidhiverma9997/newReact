import React from 'react';
import { Formik, Form, Field, ErrorMessage, } from "formik";
import { Card } from 'react-bootstrap';
import * as Yup from "yup";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from "react-router-dom";

const LoginSchema = Yup.object().shape({
    name : Yup.string()
    .required('Name is required'),
    email: Yup.string()
        .email("Invalid email address format")
        .required("Email is required"),
    password: Yup.string()
        .min(3, "Password must be 3 characters at minimum")
        .required("Password is required"),
});
const RagistrationPage = () => { 

    let navigate = useNavigate();

    return(
        <div className="container mt-5">
            <Card className="row p-5 w-50 mb-5 bg-secondary">
                <div className="col-lg-12">
                    <Formik
                        initialValues={{name :'', email: "", password: "" }}
                        validationSchema={LoginSchema}
                        onSubmit={(values) => {
                            console.log(values);
                            toast.success("Ragistration successfully!");
                            navigate("/getApi");
                        }}
                    >
                        {({ touched, errors, isSubmitting, values }) =>
                        (
                            <div >
                                <div className="row mb-3">
                                    <div className="col-lg-12 text-center">
                                        <h3 className="">Users Create</h3>
                                    </div>
                                </div>
                                <Form>
                                {/* <div className="form-group">
                                        <label htmlFor="name">Id</label>
                                        <Field
                                            type="text"
                                            name="id"
                                            placeholder="Enter id"
                                            autocomplete="off"
                                             className={`mt-2 form-control
                                      ${touched.id && errors.id ? "is-invalid" : ""}`}
                                        />
                                        <ErrorMessage
                                            component="div"
                                            name="id"
                                            className="invalid-feedback"
                                        />
                                    </div> */}
                                    <div className="form-group">
                                        <label htmlFor="userId">UserId</label>
                                        <Field
                                            type="text"
                                            name="userId"
                                            placeholder="Enter UserId"
                                            autocomplete="off"
                                            className={`mt-2 form-control
                                       ${touched.userId && errors.userId ? "is-invalid" : ""}`}
                                        />
                                        <ErrorMessage
                                            component="div"
                                            name="userId"
                                            className="invalid-feedback"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="title" className="mt-3">
                                        Title
                                        </label>
                                        <Field
                                            type="text"
                                            name="title"
                                            placeholder="Enter Title"
                                            className={`mt-2 form-control
                                                ${touched.title && errors.title
                                                    ? "is-invalid"
                                                    : ""
                                                }`}
                                        />
                                        <ErrorMessage
                                            component="div"
                                            name="title"
                                            className="invalid-feedback"
                                        />
                                    </div>
                                    <button
                                        type="submit"
                                        className="btn btn-primary btn-block mt-4"
                                    >
                                        Submit
                                    </button>
                                </Form>
                            </div>
                        )
                        }
                    </Formik>
                </div>
            </Card>
            <ToastContainer />
        </div>
    )
}
export default RagistrationPage;