import './App.css';
import { BrowserRouter as Router, Route, Routes, Link }
  from 'react-router-dom';
import { Nav, Button, Row } from 'react-bootstrap';
import Home from './pages/Home';
import Product from './pages/Product';
import Contact from './pages/Contact';
import Login from './assents/Login';
import RagistrationPage from './assents/RagistrationPage';
import Create from './components/Create';
import Edit from './components/Edit';
import Main from './components/Main';
import GetApi from './components/GetApi';
import LayOut from './layouts/Layout';
import CurdData from './components/CurdData';
import EditCourdData from './components/EditCourdData';
function App() {
  return (
    <div className='App'>
      <Router>
        <div className='container-fluid'>
          <Row className='navbar-nav'>
            <Nav className="navbar navbar-expand-lg navbar-dark bg-primary ">
              <Link className="navbar-brand  p-2" to='#'>CMD</Link>
              <div className="collapse navbar-collapse row" >
                <div className="navbar-nav col-md-10">
                  <div className="nav-item active">
                    <Link className="nav-link" to='home'>Home</Link>
                  </div>

                  <div className="nav-item">
                    <Link className="nav-link" to='contact'>Contact Us</Link>
                  </div>

                  <div className="nav-item">
                    <Link className="nav-link" to='product'>Product Us</Link>
                  </div>
                  <div className="nav-item">
                    <Link className="nav-link" to='layOut'>Layout </Link>
                  </div>
                  <div className='nav-item'>
                    <Link className='nav-link' to='curdData'>Curd Data</Link>
                  </div>

                </div>
                <div className='navbar-nav col-md-1 text-end'>
                  <div className="nav-item">
                    <Link className="nav-link" to='login'>
                      <Button className="btn btn-success float-right text-light" type="button"
                      >Sign In</Button>
                    </Link>
                  </div>
                  {/* <div className="nav-item  text-end">
                    <Link className="nav-link" to='signIn'>
                      <Button className="btn btn-outline-success float-right text-light" type="button"
                      >Sign Out</Button>
                    </Link>
                  </div> */}

                </div>
              </div>
            </Nav>
          </Row>
        </div>
        <Routes>
          <Route path='/home' element={<Home />} />
          <Route path='/product' element={<Product />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/login' element={<Login />} />
          <Route path='/ragistrationPage' element={<RagistrationPage />} />
          <Route path='/' element={<Main />} />
          <Route path='/create' element={<Create />} />
          <Route path='/edit' element={<Edit />} />
          <Route path='/getApi' element={<GetApi />} />
          <Route path='/layOut' element={<LayOut />} />
          <Route path='/curdData' element={<CurdData/>} />
          <Route path='/editCourdData' element={<EditCourdData/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
