import React, { useState } from 'react';
import Object from './Object';
const Layout = () => {
    const str = ['apple', 'banana', 'mango', 'orange'];

    const arry = [10, 12, 14, 35, 33, 56, 58, 60];
    const arry2 = arry.filter(demo);
    console.log('arry2>>', arry2);
    function demo(a) {
        return a > 14;
    }

    const every = arry.every(disk);
    console.log('every>>', every);
    function disk(aa) {
        return aa > 12;
    }

    const array1 = [1, 30, 39, 29, 10, 13];
    const isBelowThreshold = (currentValue) => currentValue < 40;
    console.log('arrowFunEvery>>', array1.every(isBelowThreshold));

    const filterOne = (filterValue) => filterValue < 29;
    console.log('filterOne>>>', array1.filter(filterOne));

    const some = arry.some(someV);
    console.log('some>>', some);
    function someV(b) {
        return b > 33;
    }
    const joinM = arry.join('-');
    console.log('joinM>>', joinM);

    const popM = arry.pop();
    console.log('popM>>', popM);

    const pushM = str.push('Nisha');
    console.log('pushM>>', pushM);

    const shiftMethod = str.shift();
    console.log('shiftMethod>>', shiftMethod);

    const unshiftM = str.unshift('pineapple');
    console.log('unshiftM--->', unshiftM);

    const sliceMethod = str.slice(3);
    console.log('sliceMethod>>', sliceMethod);

    const spliceM = str.splice(1, 3, 'lemon', 'kiwi');
    console.log('spliceM>>', spliceM);

    const lengthq = arry.length;
    console.log('lengthq>>', lengthq)

    const concatValue = arry.concat(str, arry2);
    console.log('concateValue>>', concatValue);

    const sortM = arry.sort();
    console.log('sortM>>', sortM);

    const reverseM = str.reverse();
    console.log('reverseM>>', reverseM);

    let value1 = '';
    const foreachM = arry.forEach(checkM);
    console.log('foreachM>>', foreachM);
    function checkM(aa) {
        value1 += aa;
    }

    const MapM = arry.map(demo1);
    console.log('MapM>>', MapM);
    function demo1(num) {
        return num + 3;
    }

    const include = str.includes('apple');
    console.log('include>>', include);

    const date = new Date();
    console.log('date>>', date);

    let data = '';
    for (var a = 0; a < arry.length; a++) {
        data += arry[a];
        //     console.log('data>>',data);
    }
    console.log('data>>', data);

    const arrValue = [12, 32, 34, 54, 35, 5, 46, 78, 97, 65];
    let num = '';
    for (let a of arrValue) {
        num += a;
    }
    console.log('num>>', num);

    const [name, setName] = useState('Manu')
    const [values, setValues] = useState({
        brand: "Ford",
        model: "Mustang",
        year: "1964",
        color: "red"
    })

    const person = {
        firstName: "John",
        lastName: "Doe",
        id: 5566,
        fullName: function () {
            return this.firstName + " " + this.lastName;
        }
    };
    // person.fullName()
    console.log('fullName>>', person.fullName());

    const spreedOpt = {
        name: 'gagan',
        email: 'gagan12@gmail.com',
        password: '2357678',
        address: 'alg',
        qualification: 'deploma'
    }

    const secondSpreed = {
        firstName: 'Manish',
        lastName: 'Sharma',
        email: 'manish@gmail.com',
        address: 'agra'
    }
    const addSpreed = {
        ...spreedOpt, ...secondSpreed
    }
    console.log('addSpreed>>', addSpreed)
    function demoDetails(p1, p2) {
        const add = p1 + p2;
        const sub = p1 - p2;
        const mod = p1 % p2;
        return [add, sub, mod];
    }
    const [add, sub, mod] = demoDetails(45, 23);
    console.log('add>>', add + ' ' + 'sub>>', sub + ' ' + 'mod>>', mod);

    // const objeDestructur = {

    // }
    console.log('output>>', '1' + 2 + 3 + 4);
    console.log('second>>>', '4' - 2 / 4 + 1);

    return (
        <>
            <div className="bg-secondary text-white p-2">
                <h3>Array Method</h3>
                <p>Filter :{arry2}</p>
                <p>Join :{joinM}</p>
                <p>Pop :{popM}</p>
                <p>Push :{pushM}</p>
                <p>Shift :{shiftMethod}</p>
                <p>Unshift :{unshiftM}</p>
                <p>Slice :{sliceMethod}</p>
                <p>Splice :{spliceM}</p>
                <p>Length :{lengthq}</p>
                <p>Concat :{concatValue}</p>
                <p>Sort :{sortM}</p>
                <p>Reverse :{reverseM}</p>
                <p>For Each :{foreachM}</p>
                <p>For Loop :{data}</p><p>Every :{every}</p>
                <p>Some :{some}</p>
            </div>
            <div className="text-warning bg-info p-2">
                <h2>String Method</h2>
                <h4>Name :{name}</h4>
                <button className='bg-success ' onClick={() => setName('Surjeet Sharma')}>Click here</button>
                <h2>This is a {values.brand}It is a {values.color} {values.model} from {values.year}.</h2>
            </div>
            <Object />
        </>
    )
}
export default Layout;