// import React, { useState, useEffect } from 'react';
import { Container, Row } from 'react-bootstrap';
// import axios from 'axios';

const Curd = () => {
   
    return (
        <>
            <div className='container'>
                <Container className='card'>
                    <Row className="justify-content-center">
                        <div className="card-header d-grid gap-2 d-md-block mt-5 justify-content-end">
                            <button className="btn btn-primary" type="button">Add User</button>
                        </div>
                        <div className="card-body">Table Structure
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Username</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {/* {
                                        items.map((data, index) =>
                                            <tr>
                                                <td>{index + 1}</td>
                                                <td>{data.name}</td>
                                                <td>{data.username}</td>
                                                <td>{data.email}</td>
                                                <td>
                                                    <i className="fa-trash bg-danger p-2 m-2"></i>
                                                    <i className="fa-trash bg-danger p-2"></i>
                                                </td>
                                            </tr>
                                        )
                                    } */}

                                </tbody>
                            </table>
                        </div>
                        <div className="card-footer">Footer
                            <nav aria-label="Page navigation example">
                                <ul className="pagination justify-content-center mt-3">
                                    <li className="page-item disabled">
                                        <a className="page-link" href="#" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                    <li className="page-item"><a className="page-link" href="#">1</a></li>
                                    <li className="page-item"><a className="page-link" href="#">2</a></li>
                                    <li className="page-item"><a className="page-link" href="#">3</a></li>
                                    <li className="page-item">
                                        <a className="page-link" href="#" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </Row>
                </Container>

            </div>
        </>
    )
}
export default Curd;