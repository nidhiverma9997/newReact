import React, { useState } from 'react';

const ProfilePage = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    // States for checking the errors
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState(false);

    // Handling the name change
    const handleName = (e) => {
        setName(e.target.value);
        console.log('name>>', name)
        setSubmitted(false);
    };
    // Handling the email change
    const handleEmail = (e) => {
        setEmail(e.target.value);
        console.log('email>>', email)
        setSubmitted(false);
    };
    // Handling the password change
    const handlePassword = (e) => {
        setPassword(e.target.value);
        setSubmitted(false);
    };
    // Handling the form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        if (name === '' || email === '' || password === '') {
            setError(true);

        } else {
            setSubmitted(true);
            setError(false);
        }
    };
    // Showing success message
    const successMessage = () => {
        return (
            <div
                className="success"
                style={{
                    display: submitted ? '' : 'none',
                }}>
                <p>User {name} successfully registered!!</p>
            </div>
        );
    };
    // Showing error message if error is true
    // const errorMessage = () => {
    //     return (
    //         <div
    //             className="error"
    //             style={{
    //                 display: error ? '' : 'none',
    //             }}>
    //             <p>Please enter all the fields</p>
    //         </div>
    //     );
    // };
    return (
        <>
            {/* <h1>Profile Page</h1> */}
            <div className="messages">
                {/* {errorMessage()} */}
                {successMessage()}
            </div>
            <form>
                <div className=' p-3'>
                    <label className="label">Name</label>
                    <input onChange={handleName} className="input"
                        value={name} type="text" />

                    <label className="label">Email</label>
                    <input onChange={handleEmail} className="input"
                        value={email} type="email" />

                    <label className="label">Password</label>
                    <input onChange={handlePassword} className="input"
                        value={password} type="password" />

                    <button onClick={handleSubmit} className="btn" type="submit">
                        Submit
                    </button>
                </div>
            </form >
        </>
    )
}
export default ProfilePage;