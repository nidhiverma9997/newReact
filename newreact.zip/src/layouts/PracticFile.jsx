import React from 'react';

const PracticFile = () => {

    let authentication = true;

    const ValusPro = () => {
        let numString = 'this is a new person';
        console.log('numString>>', numString)
        // alert("Great Shot!");
    }

    const numValues = () => {
        let oldString = 'this is a old person';
        console.log('oldString>>', oldString)
    }


    function MissedGoal() {
        return <h1>MISSED!</h1>;
    }

    function MadeGoal() {
        return <h1>GOAL!</h1>;
    }

    function Goal(props) {
        const isGoal = props.isGoal;
        if (isGoal) {
            return <MadeGoal />;
        }
        return <MissedGoal />;
    }

    return (
        <>
            <h3>This is Tanary Operator</h3>
            <button onClick={ValusPro}>Click Me</button>
            <Goal isGoal={false} />
            {
                authentication ? ValusPro() : numValues()
            }
        </>
    )
}
export default PracticFile;