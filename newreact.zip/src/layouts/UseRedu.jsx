import React, { useReducer } from 'react';

// function init(initialCount) {
//     return {count: initialCount};
//   }

const initialState = { count: 0 };
function reducer(state, action) {
    switch (action.type) {
        case 'increment':
            return { count: state.count + 1 };
        case 'decrement':
            return { count: state.count - 1 };
        // case 'reset':
        //     return {count : state};
        default:
            throw new Error();
    }
}

const UseRedu = () => {
    const [state, dispatch] = useReducer(reducer, initialState);
    return (
        <>
            <h5>Count: {state.count}</h5>

            <button onClick={() => dispatch({ type: 'decrement' })}>decrement</button>
            <button onClick={() => dispatch({ type: 'increment' })}>increment</button>
            <button onClick={() => dispatch({ type: 'reset' })}>Reset</button>
        </>
    )
}
export default UseRedu;