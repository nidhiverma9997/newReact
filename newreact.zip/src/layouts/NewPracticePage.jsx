import React from 'react';

const NewPracticePage = () => {
    return(
        <>
            
        </>
    )
}
export default NewPracticePage;