import React, { } from 'react';
// import axios from 'axios';
const ArrayMethod = () => {
    //filter method
    const arryValue = [10, 34, 35, 67, 32, 45, 56, 75, 46];
    const filterValue = (Num) => Num > 34;
    console.log('filterValue>>', arryValue.filter(filterValue));

    const everyVlaue = (value) => value > 32;
    console.log('everyValue>>', arryValue.every(everyVlaue));
    console.log('someValue>>', arryValue.some(everyVlaue));
    // console.log('mapValue>>',arryValue.map(everyVlaue));

    // var add = (function () {
    //     var counter = 0;
    //     return function () { counter += 1; return counter }
    // })();
    // add();

    // let user = {
    //     firstName: "John"
    // };

    // function func() {
    //     // alert(this.firstName);
    // }
    // let funcUser = func.bind(user);
    // funcUser();


    // const [data , setData]= useState([]);
    // useEffect(async()=>{
    //      await axios.get('')
    // })

    // alert("Hello");

    // [1, 2].forEach(alert);

    // let message;
    // message = 'hii!';
    // alert(message);


    let Name;
    Name = 'gagan';
    Name = 'Ram';
    console.log('Name>>', Name)

    const COLOR_RED = "#F00";
    const COLOR_GREEN = "#0F0";
    const COLOR_BLUE = "#00F";
    const COLOR_ORANGE = "#FF7F00";


    let color = COLOR_ORANGE;
    console.log('color>>', color)
    console.log('color', COLOR_RED)
    // alert(color);

    let num = 4756;
    console.log('num>>', num);

    console.log('numConvert>>', String(num));

    let demo = 2;
    let disk = -demo;
    console.log('disk>>', disk);

    let a = "" + 1 + 0
    let b = "" - 1 + 0
    let c = true + false
    let d = 6 / "3"
    let e = "2" * "3"
    let f = 4 + 5 + "px"
    let g = "$" + 4 + 5
    let h = "4" - 2
    let i = "4px" - 2
    let j = "  -9  " + 5
    let k = "  -9  " - 5
    let l = null + 1
    let m = undefined + 1
    let n = " \t \n" - 2

    console.log(`a ${a} b ${b} c ${c} d ${d} e ${e} f ${f} g ${g} h ${h} i ${i} j ${j} k ${k} l ${l} m ${m} n ${n}`);
    // alert( undefined  > 0 );  // (1) false
    // alert( undefined  == 0 ); // (2) false
    // alert(undefined  >= 0 ); // (3) false


    // let age = prompt('age?', 18);
    // let message =
    // //  (age < 3) ? 'Hi, sir!' :
    // //     (age < 18) ? 'Hello!' :
    //         (age > 100) ? 'Greetings!' :
    //             'What an unusual age!';
    // alert(message);

    // if (null || -1 && 1) alert( 'third' );
    return (
        <>
            {/* <ul>
            {
               filterValue.map((d)=> 
                        <li>{d.filterValue}</li>
               )
            }
         </ul> */}

        </>
    )
}
export default ArrayMethod;