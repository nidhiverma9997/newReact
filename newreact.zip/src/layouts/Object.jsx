import React from 'react';

const Object = () => {
    const obj = {
        name: 'sangeeta',
        age: 25,
        email: 'sangeeta@gmail.com',
        address: 'mathura',
        rollNo: 5664,
        grade: 'A+',
        demo: function () {
            return this.rollNo + ' ' + this.grade;
        }
    }

    // for in method
    let newV = '';
    for (let vv in obj) {
        newV += obj[vv]
    }
    console.log('ObjD>> ', obj)
    console.log('ObjData>> ', newV)
    console.log(`Obj>>> ${obj.name}  ${obj.age}  ${obj.email} ${obj.demo()}`);
    let myString = JSON.stringify(obj);
    console.log('myString>>', myString)  
    let myParse = JSON.parse(myString);
    console.log('myParse>>', myParse);
    {
        let metaValue = 'this is a block scope';
        console.log('metaValue>>', metaValue);
    }
    var memoa = 'this is a Globle Scope';
    function funScope() {
        // let num22 = 33;
        // let num21 = 65;
        let sum22 = 'this is a Local Scope';
        console.log('memoa>>', memoa);
        console.log('sum22>>', sum22);
        //   const va = 75;
    }
    console.log('memoa>>', memoa);
    funScope();
    // const objectData = {
    //     count: 0
    // };
    // Object.defineProperty(objectData, 'reset', {
    //     get: function () {
    //         this.count = 0;
    //     }
    // });
    // Object.defineProperty(objectData, 'increment', {
    //     get: function () {
    //         this.count++;
    //     }
    // });
    // Object.defineProperty(objectData, 'decrement', {
    //     get: function () {
    //         this.count--;
    //     }
    // });
    // objectData.reset;
    // objectData.increment;
    // objectData.decrement;
    // console.log('objectData>>', objectData.count);
    return (
        <>
            <h1>Object</h1>
            <h2>Scope</h2>
            <h2>Hosting</h2>
        </>
    )
}
export default Object;