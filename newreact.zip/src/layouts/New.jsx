import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const New = () => {
    return (
        <div className='container mt-5'>
            <Container className='card'>
                <Row className="justify-content-center">
                    <div className="card-header">Header</div>
                    <div className="card-body">Content</div>
                    <div className="card-footer">Footer</div>
                </Row>
            </Container>

            <div className="toast">
                <div className="toast-header">
                    Toast Header
                </div>
                <div className="toast-body">
                    Some text inside the toast body
                </div>
            </div>
        </div>
    )
}
export default New;